package y2016_s1.q2;

import java.util.NoSuchElementException;

public class Queue<E> {

    private Node<E> head;
    private Node<E> tail;
    private int size;

    public Queue(E[] items) {
        for (E item : items) {
            enqueue(item);
        }
    }

    public Queue() {}

    public void enqueue(E e) {
        if (isEmpty()) {
            head = tail = new Node<>(e);
        } else {
            Node<E> newNode = new Node<>(e);
            tail.next = newNode;
            tail = newNode;
        }
        size++;
    }

    public E dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException("The queue is empty");
        } else {
            E toRemove;
            toRemove = head.element;
            if (size == 1) {
                head = tail = null;
            } else {
                head = head.next;
            }
            size--;
            return toRemove;
        }
    }

    public E getElement(int i) {
        Node<E> current = head;
        for (int j = 0; j < i; j++) {
            current = current.next;
        }
        return current.element;
    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        Node<E> current = head;
        while (current != null) {
            sb.append(current.element);
            if (current.next != null) {
                sb.append(", ");
            }
            current = current.next;
        }
        sb.append("]");
        return sb.toString();
    }

    private static class Node<E> {
        private E element;
        private Node<E> next;

        Node(E element) {
            this.element = element;
        }
    }

}
