package y2016_s1.q2;

import java.util.Scanner;

public class TestQueue {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Queue<Character> lookUpQueue = new Queue<>();
        char[] alphabets = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '_'};

        for (char alp : alphabets) {
            lookUpQueue.enqueue(alp);
        }

        System.out.println("Queue: " + lookUpQueue);
        System.out.print("Index: [");
        for (int i = 0; i < lookUpQueue.getSize(); i++) {
            if (i != lookUpQueue.getSize() - 1) {
                System.out.print(i + ", ");
            } else {
                System.out.print(i);
            }
        }
        System.out.println("]");

        System.out.print("\nHow many times will you enter a number: ");
        int n = sc.nextInt();
        int[] indices = new int[n];
        System.out.println("(Please enter your number(s) between 0-26.)");
        for (int i = 0; i < n; i++) {
            System.out.print("Enter number " + (i + 1) + " >> ");
            indices[i] = sc.nextInt();
        }
        System.out.print("The entered numbers are [");
        for (int i = 0; i < indices.length; i++) {
            if (i != indices.length - 1) {
                System.out.print(indices[i] + ", ");
            } else {
                System.out.print(indices[i]);
            }
        }
        System.out.println("]");

        System.out.print("The deciphered values are ");
        StringBuilder sbResult = new StringBuilder();
        for (int index : indices) {
            sbResult.append(lookUpQueue.getElement(index));
        }

        if (sbResult.isEmpty()) {
            System.out.println("-Cannot decipher. No value was entered.-");
        } else {
            System.out.println(sbResult);
        }

    }
}
