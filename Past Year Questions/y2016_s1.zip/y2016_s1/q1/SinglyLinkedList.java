package y2016_s1.q1;

import java.util.NoSuchElementException;

public class SinglyLinkedList<E> {

    private Node<E> head;
    private Node<E> tail;
    private int size;

    public SinglyLinkedList() {}

    public boolean isEmpty() {
        return size == 0;
    }

    public void add(E e) {      // act as add last
        if (isEmpty()) {
            head = tail = new Node<>(e);
        } else {
            Node<E> newNode = new Node<>(e);
            tail.next = newNode;
            tail = newNode;
        }
        size++;
    }

    public void removeElement(E e) {
        Node<E> current = head;
        Node<E> prev = current;
        while (current != null) {
            if (current.element.equals(e)) {
                if (size == 1) {
                    head = tail = null;
                } else if (current == head) {
                    head = head.next;
                } else if (current == tail) {
                    prev.next = null;
                    tail = prev;
                } else {
                    prev.next = current.next;
                }
                size--;
                return;
            }
            prev = current;
            current = current.next;
        }
        throw new NoSuchElementException(e + " is not exist in the linked list");
    }

    public void printList() {
        StringBuilder sb = new StringBuilder();
        Node<E> current = head;
        while (current != null) {
            sb.append(current.element);
            if (current.next != null) {
                sb.append(", ");
            } else {
                sb.append(".");
            }
            current = current.next;
        }
        System.out.println(sb);
    }

    public int getSize() {
        return size;
    }

    public boolean contains(E e) {
        Node<E> current = head;
        while (current != null) {
            if (current.element.equals(e)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    public void replace(E e, E newE) {
        if (!contains(e)) {
            throw new NoSuchElementException(e + " is not exist in the list");
        }
        Node<E> current = head;
        while (current != null) {
            if (current.element.equals(e)) {
                current.element = newE;
            }
            current = current.next;
        }
    }

    private static class Node<E> {
        private E element;
        private Node<E> next;

        Node(E element) {
            this.element = element;
        }
    }
}
