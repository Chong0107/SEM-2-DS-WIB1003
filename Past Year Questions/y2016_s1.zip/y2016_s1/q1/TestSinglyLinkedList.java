package y2016_s1.q1;

import java.util.Scanner;

public class TestSinglyLinkedList {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        SinglyLinkedList<String> list = new SinglyLinkedList<>();

        System.out.println("Enter your list of food to order. Enter 'n' to end.");
        String input = "";
        while (true) {
            input = sc.nextLine().trim();
            if (input.equals("n")) {
                break;
            } else {
                list.add(input);
            }
        }

        System.out.println("\nYou have ordered the following menu :");
        list.printList();

        System.out.println("\nThe number of items ordered are : " + list.getSize());

        do {
            System.out.println("\nDo you want to change your order? Enter 'y' for yes, 'n' to proceed.");
            input = sc.next();
            sc.nextLine();

            if (input.equals("y")) {
                System.out.println("Enter the old menu item : ");
                String oldItem = sc.nextLine().trim();
                System.out.println("\nEnter the new menu item : ");
                String newItem = sc.nextLine().trim();

                if (list.contains(oldItem)) {
                    list.replace(oldItem, newItem);
                } else {
                    System.out.println("\nThe item you want to replace is not exist in the list.");
                }
                System.out.println("\nThe new order list is :");
                list.printList();
            } else if (!input.equals("n")) {
                System.out.println("Please enter either 'y' or 'n' only.");
            }
        } while (!input.equals("y") && !input.equals("n"));

        do {
            System.out.println("\nDo you want to remove any of your menu items? Enter 'y' for yes, 'n' to proceed.");
            input = sc.next();
            sc.nextLine();
            if (input.equals("y")) {
                System.out.println("\nEnter a menu item to remove :");
                String toRemove = sc.nextLine().trim();
                if (list.contains(toRemove)) {
                    list.removeElement(toRemove);
                } else {
                    System.out.println("\nItem you want to remove is not in the existing order list.");
                }

                System.out.println("\nThe number of updated order is :" + list.getSize());
                System.out.println("The updated order is :");
                list.printList();

            } else if (input.equals("n")) {
                System.out.println("\nThe number of order is :" + list.getSize());
                System.out.println("You ordered the following :");
                list.printList();
            } else {
                System.out.println("Please enter either 'y' or 'n' only.");
            }
        } while (!input.equals("y") && !input.equals("n"));

        System.out.println("\nYour order is complete. Thank you!");
    }
}
