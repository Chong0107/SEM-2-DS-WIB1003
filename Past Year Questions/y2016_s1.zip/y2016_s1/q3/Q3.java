package y2016_s1.q3;

import java.util.Arrays;

public class Q3 {
    public static void main(String[] args) {
        int[] num = {82, 54, 71, 86, 43, 99};
        theSort(num);
    }

    public static void theSort(int[] num) {
        int numOfRepetition = 0;
        for (int i = 1; i < num.length; i++) {
            int currentElement = num[i];
            int j;
            System.out.println("Insert element at " + i + " into sorted sublist " + Arrays.toString(num));
            for (j = i - 1; j >= 0 && num[j] < currentElement; j--) {
                num[j + 1] = num[j];
                System.out.println("\tRearrange sorted sublist (" + 0 + "-" + i + ") " + Arrays.toString(num));
                numOfRepetition++;
            }
            System.out.println("j: " + j);
            if (currentElement != num[j + 1]) {
                num[j + 1] = currentElement;
                System.out.println("\tRearranging result (" + 0 + "-" + i + ") " + Arrays.toString(num));
            }
            numOfRepetition++;
            System.out.println();
        }
        System.out.println("Total iteration needed: " + numOfRepetition);
    }
}
